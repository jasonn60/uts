import 'package:flutter/material.dart';
import './view.dart';

abstract class PerempuanController extends State<PerempuanView>{

}