import 'package:flutter/material.dart';
import './controller.dart';
import './ContentPage.dart';

class PerempuanView extends StatefulWidget {
  @override
  _PerempuanViewState createState() => _PerempuanViewState();
}

class _PerempuanViewState extends State<PerempuanView> {
  List<String> names = [
    'Malahayati',
    'Martha Christina Tiahahu',
    'Nyi Ageng Serang',
    'Cut Nyak Dhien',
    'Cut Nyak Meutia',
    'Maria Walanda Maramis',
    'Dewi Sartika',
    'Andi Depu',
    'Rasuna Said',
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('List Pahlawan Wanita'),
        backgroundColor: Colors.black,
      ),
      body: GridView.count(
        crossAxisCount: 3,
        children: List.generate(names.length, (index){
          return GridTile(
            child: GestureDetector(
              child: Container(
                width: 55.0,
                height: 60.0,
                 margin: const EdgeInsets.all(3.0),
                 padding: const EdgeInsets.all(3.0),
                decoration: BoxDecoration(
                  image: DecorationImage(
                    fit: BoxFit.fill,
                    alignment: FractionalOffset(0.2, 0.6),
                    image: AssetImage('images/'+ names[index]+'.jpg'),
                  )
                ),
              ),
          onTap: (){
            Navigator.push(context, MaterialPageRoute(
              builder: (BuildContext context){
                return ContentPage(value: names[index]); // kirim data 
              }
            ));
            },
            ),
          );
        }),
      ),
    );
  }
}