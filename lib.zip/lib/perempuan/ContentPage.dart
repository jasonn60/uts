import 'package:flutter/material.dart';


class ContentPage extends StatelessWidget{
  Map<String, String> names ={
  'Malahayati':'Malahayati(1550 - Juni 1615)',
  'Martha Christina Tiahahu':'Martha Christina Tiahahu(4 Januari 1800 – 2 Januari 1818)',
  'Nyi Ageng Serang':'Nyi Ageng Serang(Jawa Tengah, 1752 - Yogyakarta, 1828)',
  'Cut Nyak Dhien':'Cut Nyak Dhien(1848 - 	6 November 1908)',
  'Cut Nyak Meutia':'Cut Nyak Meutia(15 Februari 1870 – 24 Oktober 1910)',
  'Maria Walanda Maramis':'Maria Walanda Maramis(1 Desember 1872 – 22 April 1924)',
  'Dewi Sartika':'Dewi Sartika(4 Desember 1884 - 11 September 1947)',
  'Andi Depu':'Andi Depu(Agustus 1907 - 18 Juni 1985)',
  'Rasuna Said':'Rasuna Said(14 September 1910 – 2 November 1965)',
  };
  Map<String, String> desc ={
    'Malahayati':'''pejuang asal Kesultanan Aceh yang lahir di Aceh Besar pada tahun 1550. Perempuan tangguh ini memimpin 2.000 orang pasukan Inong Balee (janda-janda pahlawan yang telah syahid). Dengan keteguhan hati, mereka berperang melawan kapal dan benteng Belanda sekaligus membunuh Cornelis de Houtman!

Peristiwa ini terjadi pada tanggal 11 September 1599. Berkat keberaniannya, Malahayati mendapat gelar Laksamana. Namun, Malahayati gugur di tahun 1615 kala melindungi Teluk Krueng Raya dari serangan Portugis yang dipimpin oleh Laksamana Alfonso De Castro.''',
    'Martha Christina Tiahahu':'''Martha Christina Tiahahu, pejuang dari Desa Abubu, Pulau Nusa Laut yang lahir pada tanggal 4 Januari 1800. Waktu masih berusia 17 tahun, ia sudah berani mengangkat senjata melawan penjajah Belanda. Tak hanya itu, Martha Christina Tiahahu juga selalu memberi semangat pada kaum perempuan untuk membantu laki-laki di medan pertempuran.

Sedihnya, sang ayah, Kapitan Paulus Tiahahu dijatuhi hukuman mati oleh Belanda. Sepeninggal ayahnya, kesehatan fisik dan mentalnya terganggu. Lalu, ia tertangkap bersama 39 orang lainnya dan dibawa ke Pulau Jawa dengan kapal Eversten untuk dipekerjakan paksa di perkebunan kopi.

Namun, kondisi kesehatan Martha Christina Tiahahu memburuk selama di atas kapal. Hal ini diperparah oleh dirinya yang menolak makan dan diobati. Akhirnya, ia mengembuskan napas terakhir pada 2 Januari 1818 dan disemayamkan dengan penghormatan militer ke Laut Banda.''',
    'Nyi Ageng Serang':'''Perempuan bernama asli Raden Ajeng Kustiyah Wulaningsih Retno Edi ini adalah salah satu keturunan Sunan Kalijaga. Perempuan kelahiran tahun 1752 ini adalah anak dari Pangeran Natapraja dan melawan penjajah bersama ayah dan kakaknya, Kyai Ageng Serang.

Semangatnya yang berkobar untuk membela rakyat dipicu oleh kematian kakaknya karena membela Pangeran Mangkubumi melawan Paku Buwono I yang dibantu Belanda. Ia tak pantang menyerah walau ayah, kakak, dan suaminya telah gugur. Bahkan, Nyi Ageng Serang tetap memimpin pasukan di usia 73 tahun.

Bahkan, Pangeran Diponegoro mengakui kehebatan Nyi Ageng Serang dalam menyusun strategi, hingga dipercaya menjadi salah satu penasihatnya. Namun, dua tahun sebelum Perang Diponegoro berakhir, Nyi Ageng Serang meninggal dunia di usia 76 tahun akibat wabah penyakit malaria.

''',
    'Cut Nyak Dhien':'''Masyarakat Aceh bangga memiliki sosok Cut Nyak Dhien. Tekadnya yang kuat dalam melawan Belanda dipicu oleh kematian suaminya, Ibrahim Lamnga pada 29 Juni 1878 dalam pertempuran dengan penjajah. Lalu, pada tahun 1880, Cut Nyak Dhien menikah lagi dengan Teuku Umar dan mereka bertempur bersama melawan Belanda.

Sedihnya, pada 11 Februari 1899, Teuku Umar gugur dan membuat Cut Nyak Dhien berjuang sendirian di pedalaman Meulaboh dengan pasukan kecilnya. Karena keberadaannya memberikan pengaruh kuat terhadap rakyat Aceh, Cut Nyak Dhien diasingkan ke Sumedang dan meninggal di sana pada tanggal 6 November 1908.''',
    'Cut Nyak Meutia':'''Bumi rencong melahirkan banyak perempuan pejuang yang tangguh, salah satunya adalah Cut Nyak Meutia. Awalnya, ia melakukan perlawanan terhadap Belanda dengan suaminya, Teuku Muhammad. Tetapi, suaminya berhasil ditangkap Belanda dan dihukum mati pada tahun 1905.

Sesuai wasiat suaminya sebelum gugur, Cut Nyak Meutia menikah dengan Pang Nanggroe. Mereka bertempur dengan Korps Marechausée dan membuat suaminya gugur pada 26 September 1910, tetapi Cut Nyak Meutia berhasil lolos. Ia terus melakukan perlawanan dengan sisa-sisa pasukannya, tetapi takdir berkata lain. Cut Nyak Meutia gugur pada 24 Oktober 1910.''',
    'Maria Walanda Maramis':'''Tak salah kalau Maria Walanda Maramis dijuluki sebagai Kartini dari Minahasa. Sebab, pahlawan kelahiran 1 Desember 1872 ini berupaya membebaskan perempuan dari keterbelakangan pendidikan. Maria sendiri sempat bersekolah di Sekolah Melayu di Maumbi, Minahasa Utara, selama tiga tahun dan tak bisa melanjutkan pendidikan ke tingkat yang lebih tinggi.

Akhirnya, Maria mendirikan organisasi bernama Percintaan Ibu Kepada Anak Temurunnya (PIKAT) untuk memajukan pendidikan kaum perempuan. Lewat PIKAT, kaum perempuan dibekali ilmu untuk berumah tangga, seperti memasak, menjahit, merawat bayi, dan lainnya. Maria terus aktif di PIKAT hingga kematiannya pada 22 April 1924.''',
    'Dewi Sartika':'''Selain Maria Walanda Maramis, ada juga Raden Dewi Sartika yang peduli dengan pendidikan kaum perempuan. Jasanya adalah membuat sekolah bernama Sekolah Isteri di Pendopo pada 16 Januari 1904. Lalu, sekolah ini berganti nama menjadi Sekolah Kaoetamaan Isteri di tahun 1910 dan berubah lagi menjadi Sekolah Raden Dewi pada September 1929.

Berkat jasanya dalam memperjuangkan pendidikan, Dewi Sartika dianugerahi gelar Orde van Oranje-Nassau. Selain itu, ia juga diakui sebagai Pahlawan Nasional pada 1 Desember 1966. Dewi Sartika meninggal pada 11 September 1947.''',
    'Andi Depu':'''Perempuan bernama lengkap Andi Depu Maraddia Balanipa ini adalah pejuang asal Tinambung, Polewali Mandar, Sulawesi Barat. Ia dikenal karena berhasil mempertahankan wilayahnya dari penaklukan Belanda. Bahkan, Andi Depu berani mengibarkan bendera Merah Putih saat pasukan Jepang datang di Mandar pada tahun 1942.

Atas keberaniannya, Andi Depu dianugerahi Bintang Mahaputra Tingkat IV dari Presiden Soekarno. Selain itu, Presiden Joko Widodo juga menganugerahkan gelar Pahlawan Nasional pada Andi Depu dan 5 tokoh bangsa lainnya. Ini tertuang di Keputusan Presiden Republik Indonesia Nomor 123/TK/Tahun 2018 tentang Penganugerahan Gelar Pahlawan Nasional.''',
    'Rasuna Said':''' Hajjah Rangkayo Rasuna Said atau lebih dikenal dengan nama Rasuna Said. Perannya adalah memperjuangkan persamaan hak antara perempuan dan laki-laki, sama seperti Kartini. Menurutnya, kemajuan kaum perempuan tidak hanya didapat dari mendirikan sekolah, tetapi juga melakukan perjuangan politik.

Berkat pidatonya yang mengecam pemerintahan Belanda, ia terkena hukum Speek Delict, yakni hukum kolonial Belanda untuk orang yang berbicara menentang Belanda. Ia sempat tertangkap bersama temannya, Rasimah Ismail, dan dipenjara di Semarang pada tahun 1932.

Setelah kemerdekaan, Rasuna Said aktif di Dewan Perwakilan Sumatra mewakili Sumatra Barat dan sempat diangkat menjadi anggota Dewan Perwakilan Rakyat Republik Indonesia Serikat (DPR RIS). Ia juga menjabat sebagai anggota Dewan Pertimbangan Agung hingga akhir hayatnya. Rasuna Said meninggal pada 2 November 1965 akibat penyakit kanker darah.''',
  };


  final String value; 
  // konstruktor
  ContentPage ({Key key, @required this.value}) : super(key:key);

  @override 
  Widget build(BuildContext context){
    return Scaffold(
      
      appBar: AppBar(
        title: Text(this.value),
        backgroundColor: Colors.black,
      ),

      body: SingleChildScrollView(
        child: Column(
           mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            Image.asset(
            'images/${this.value}.jpg',
            fit: BoxFit.fill,
          ),

          Container(
            height: 15.0,
          ),
         Row(
        children: <Widget>[
            Container(
                width: 15.0,
              ),
               Column(
               crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text(
                    names[this.value],
                    style: TextStyle(
                      fontSize: 13.0,
                      fontWeight: FontWeight.bold
                    )
                  ),
                   Text(
                    'Tangerang, Banten',
                    style: TextStyle(
                      color: Colors.grey,
                      fontSize: 10.0,
                    ),
                  ),
                ]
               ),   
        ],
    ),
       Container(
            
            padding: const EdgeInsets.all(16.0),
            child: Text(
              desc[this.value],
              style:TextStyle(
                fontSize: 16.0,
              ),
              textAlign: TextAlign.justify,
              softWrap: true,
              overflow: TextOverflow.clip,
            ),
           
          ),


        
          ],
        ),
      ),

    );
  }
}