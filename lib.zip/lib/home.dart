import 'package:flutter/material.dart';
import './home/view.dart';
import './pria/view.dart';
import './perempuan/view.dart';

class HomeApps extends StatefulWidget {
  @override
  _HomeAppsState createState() => _HomeAppsState();
}

class _HomeAppsState extends State<HomeApps> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'UTS',
      routes: {
        '/' : (BuildContext _) => HomeView(),
        '/pria' : (BuildContext _) => PriaView(),
        '/perempuan' : (BuildContext _) => PerempuanView(),
      },
      initialRoute: '/',
    );
  }
}
