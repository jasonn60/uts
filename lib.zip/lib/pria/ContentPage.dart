import 'package:flutter/material.dart';


class ContentPage extends StatelessWidget{
  Map<String, String> names ={
  'Ahmad Yani':'Ahmad Yani(23 Juni 1962 – 1 Oktober 1965)',
  'Jendral Soedirman':'Jendral Soedirman(12 November 1945 – 29 Januari 1950)',
  'Idham Chalid':'Idham Chalid(27 Agustus 1921 –  11 Juli 2010)',
  'KH. Hasyim Asyari':'KH. Hasyim Asyari(14 Februari 1871 – 21 Juli 1947)',
  'Ki Hajar Dewantara':'Ki Hajar Dewantara(2 Mei 1889 - 26 April 1959)',
  'Pangeran Antasari':'Pangeran Antasari(1972 - 1809)',
  'Pangeran Diponegoro':'Pangeran Diponegoro(11 November 1785 – 8 Januari 1855)',
  'Pattimura':'Pattimura(8 Juni 1783 – 16 Desember 1817)',
  'Ir. Soekarno':'Ir. Soekarno(6 Juni 1901 – 21 Juni 1970)',
  'Mohammad Hatta':'Mohammad Hatta(12 Agustus 1902 – 14 Maret 1980)',
  'Sultan Hassanudin':'Sultan Hassanudin(12 Januari 1631 – 12 Juni 1670)',
  'Agus Salim':'Agus Salim(8 Oktober 1884 - 4 November 1954)',
  'Bung Tomo':'Bung Tomo(3 Oktober 1920 – 7 Oktober 1981)',
  'Tan Malaka':'Tan Malaka(2 Juni 1897 – 21 Februari 1949)',
  };
  Map<String, String> desc ={
    'Ahmad Yani':'Pahlawan nasional yang pertama kita bahas adalah Jendral Ahmad Yani. Beliau lahir pada tanggal 19 Juni 1922 di Jenar, Purworejo, Jawa Tengah. Beliau mengawali karir militernya dengan pangkat Sersan dengan mengikuti pendidikan militer pada Dinas Topografi Militer di Malang dan secara lebih intensif di Bogor. Torehan prestasi telah diraihnya di masa perang kemerdekaan. Ahmad Yani berhasil menyita senjata Jepang di Magelang. Setelah Tentara Keamanan Rakyat (TKR) terbentuk, Dia diangkat menjadi Komandan TKR Purwokerto. Ia memimpin/mengkomandoi penumpasan pemberontakan PRRI. Pada tahun 1962, Jenderal Ahmad Yani diangkat menjadi Panglima Angkatan Darat. Ahmad Yani gugur sebagai pahlawan Revolusi, setelah ditembak di depan kamar tidurnya pada tanggal 1 Oktober 1965 . Jenazahnya kemudian ditemukan di Lubang Buaya, Jakarta Timur bersama dengan jasad 6 perwira lainnya.',
    'Jendral Soedirman':'Dikenal sebagai salah satu pahlawan Indonesia, jasa-jasanya sangat dikenang dalam memperjuangkan kemerdekaan Indonesia. Jenderal Besar Soedirman menurut Ejaan Soewandi dibaca Sudirman, Ia merupakan salah satu orang yang memperoleh pangkat bintang lima selain Soeharto dan A.H Nasution. Jenderal besar Indonesia ini lahir di Bodas Karangjati, Rembang, Purbalingga, 24 Januari 1916. Ayahnya bernama Karsid Kartawiuraji dan ibunya bernama Siyem. Namun ia lebih banyak tinggal bersama pamannya yang bernama Raden Cokrosunaryo setelah diadopsi. Ketika Sudirman pindah ke Cilacap di tahun 1916, ia bergabung dengan organisasi Islam Muhammadiyah dan menjadi siswa yang rajin serta aktif dalam kegiatan ekstrakurikuler. Kemampuannya dalam memimpin dan berorganisasi serta ketaatan dalam Islam menjadikan ia dihormati oleh masyarakat. Jenderal Sudirman merupakan salah satu tokoh besar di antara sedikit orang lainnya yang pernah dilahirkan oleh suatu revolusi. Saat usianya masih 31 tahun ia sudah menjadi seorang jenderal.Meski menderita sakit paru-paru yang parah, ia tetap bergerilya melawan Belanda. Ia berlatar belakang seorang guru HIS Muhammadiyah di Cilacap dan giat di kepanduan Hizbul Wathan.',
    'Idham Chalid':'''Dr. KH. Idham Chalid merupakan salah satu politisi yang berpengaruh pada massanya, dimana beliau pernah menjabat Wakil Perdana Menteri Indonesia dan juga pernah menjabat sebagai ketua MPR dan DPR.

Tepatnya pada tanggal 19 Desember 2016, sebagai penghargaan atas jasa beliau bagi negara. Pemerintah Republik Indonesia mengabadikan beliau dalam uang kertas pecahan Rp. 5000.''',
    'KH. Hasyim Asyari':'''Kyai Haji Mohammad Hasyim Asyarie adalah pahlawan nasional yang mendirikan organisasi massa islam terbesar di Indonesia yaitu Nahdlatul Ulama.

Beliau dilahirkan pada tanggal 10 April 1875 atau menurut penanggalan arab pada tanggal 24 Dzulqaidah 1287H di Desa Gedang, Kecamatan Diwek, Kabupaten Jombang, Jawa Timur.Hasyim Asyari seorang intelektual muslim yang berjuang di massa kemerdekaan dengan memiliki gagasan-gagasan yang damai dan lestari hingga sekarang ini.''',
    'Ki Hajar Dewantara':'''Ki Hajar Dewantara lahir di Yogyakarta pada tanggal 2 Mei 1889 dan meninggal pada tanggal 26 April 1959 di Yogyakarta.

Ki Hajar Dewantara atau nama sebelumnya Raden Mas Soewardi Soerjaningrat diganti sejak tahun 1922. Beliau adalah pahlawan nasional Indonesia sekaligus sebagai seorang aktivis pergerakan kemerdekaan Indonesia, politisi dan juga seorang pelopor dalam bidang pendidikan kaum pribumi di masa penjajahan belanda.

Beliau mendirikan Perguruan Tinggi Taman Siswa di Yogyakarta yang merupakan lembaga pendidikan yang memberikan kesempatan pada masyarakat pribumi untuk mendapatkan hak pendidikan seperti halnya para bangsawan dan orang-orang belanda.''',
    'Pangeran Antasari':'''Salah satu Pahlawan nasional Indonesia yang berjuang untuk melawan penjajahan Belanda di daerah Banjar, Kalimantan Selatan. Pangeran Antasari lahir pada tahun 1797 di Banjar.

Pada tanggal 14 Maret 1862, Pangeran Antasari diangkat sebagai Sultan banjar menyandang gelar Panembahan Amirudin Mukminin yaitu sebagai pemimpin pemerintah, pemuka agama tinggi dan panglima perang.

Untuk menghargai jasanya, pada tanggal 27 Maret 1968, beliau dianugrahi gelar sebagai Pahlawan Nasional dan Kemerdekaan oleh Pemerintah Republik Indonesia.''',
    'Pangeran Diponegoro':'''Pangeran AntasariPerang ini disebut sebagai Perang Jawa karena berkobar di hampir seluruh daerah di Pulau Jawa dan menjadi salah satu perang terbesar yang pernah terjadi dalam sejarah perjuangan melawan Belanda. Meskipun akhirnya dimenangkan pihak Belanda, Pangeran Diponegoro sempat membuat Belanda mengalami kesulitan dan kerugian akibat gugurnya ribuan serdadu Belanda.''',
    'Pattimura':'''Thomas Matulessy atau yang lebih dikenal dengan Pattimura adalah pahlawan bangsa yang berperan sebagai panglima perang dalam perlawanan rakyat Maluku dengan tentara VOC Belanda.

Dengan wibawa dan kepemimpinannya, Pattimura berhasil menyatukan kerajaan Nusantara, tepatnya Ternate dan Tidore untuk menghadapi penjajah pada tahun 1817.''',
    'Ir. Soekarno':'''Soekarno lahir pada tanggal 6 Juni 1901 di Surabaya dan meninggal di dunia pada tanggal 14 Maret 1980 pada usia 77 tahun.

Ir. Soekarno adalah presiden pertama Indonesia bersama wakilnya Drs. Mohammad Hatta. Ir. Soekarno menjadi proklamator kemerdekaan Indonesia bersama Mohammad Hatta pada tanggal 17 Agustus 1954. Beliau juga berperan sebagai pencetus dasar negara Pancasila yang kita gunakan hingga saat ini.''',
    'Mohammad Hatta':'''Mohammad Hatta atau dikenal dengan nama Bung Hatta adalah salah satu seorang pahlawan nasional yang berperan besar dalam proklamasi kemerdekaan Indonesia.

Bung Hatta adalah seorang pejuang, beliau mendapat gelar sebagai pahlawan proklamator, negarawan, ekonom dan juga menjabat sebagai wakil presiden. Beliau bersama dengan Soekarno berperan penting dalam kemerdekaan republik Indonesia dari penjajahan Hindia Belanda dan kemudian memproklamasikan kemerdekaan Republik Indonesia pada tanggal 17 Agustus 1945.''',
    'Sultan Hassanudin':'''Sultan Hassanudin dijuluki sebagai Ayam Jantan dari Timur dan menjadi salah satu pahlawan nasional kemerdekaan Indonesia yang berasal dari Sulawesi Selatan.

Setelah dia diangkat tahta menjadi sultan dari Kerajaan Gowa, Dia kemudian berupaya menyatukan kerajaan-kerajaan kecil Indonesia Timur dan memberikan perlawanan sengit ke pihak Belanda.''',
    'Agus Salim':'''Pada awal berdirinya Republik Indonesia, Agus Salim sudah memberikan peranan penting dalam pergerakan kemerdekaan bangsa ini. Jejak Agus Salim kacah politik sudah ada sebelum kemerdekaan. Beliau adalah pimpinan organisasi Islam terbesar saat itu yaitu Serikat Islam.

Agus Salim menguasai beberapa Bahasa asing dan merupakan diplomat yang ulung.''',
    'Bung Tomo':'''Bung Tomo atau Sutomo adalah salah satu pahlawan nasional yang berasal dari Surabaya.

Aksi heroiknya membangkitkan semangat arek-arek Suroboyo dalam melawan kembali tentara Nederlandsch Indie Civil Administratie (NICA) Belanda pada pertempuran 10 November.

Selain itu, Bung Tomo juga merupakan seorang jurnalis asal Surabaya ini dikenal dengan semboyannya  “Merdeka atau Mati” dalam pertempuran tersebut. Nah, pertempuran Surabaya ini di peringati sebagai hari Pahlawan.''',
    'Tan Malaka':'''Tan Malaka adalah salah satu pahlawan nasional kemerdekaan Indonesia yang mana sering dilupakan jasa-jasanya. Beliau sudah berjuang dalam melawan penjajahan Pemerintah Belanda.

Dia memiliki pemikiran dan tulisan yang telah menginspirasi tokoh-tokoh lainnya seperti Soekarno, Hatta, Sjahrir dalam memperjuangkan kemerdekaan bangsa Indonesia.''',
  };


  final String value; 
  // konstruktor
  ContentPage ({Key key, @required this.value}) : super(key:key);

  @override 
  Widget build(BuildContext context){
    return Scaffold(
      
      appBar: AppBar(
        title: Text(this.value),
        backgroundColor: Colors.black,
      ),

      body: SingleChildScrollView(
        child: Column(
           mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            Image.asset(
            'images/${this.value}.jpg',
            fit: BoxFit.fill,
          ),

          Container(
            height: 15.0,
          ),
         Row(
        children: <Widget>[
            Container(
                width: 15.0,
              ),
               Column(
               crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text(
                    names[this.value],
                    style: TextStyle(
                      fontSize: 13.0,
                      fontWeight: FontWeight.bold
                    )
                  ),
                   Text(
                    'Tangerang, Banten',
                    style: TextStyle(
                      color: Colors.grey,
                      fontSize: 10.0,
                    ),
                  ),
                ]
               ),   
        ],
    ),
       Container(
            
            padding: const EdgeInsets.all(16.0),
            child: Text(
              desc[this.value],
              style:TextStyle(
                fontSize: 16.0,
              ),
              textAlign: TextAlign.justify,
              softWrap: true,
              overflow: TextOverflow.clip,
            ),
           
          ),


        
          ],
        ),
      ),

    );
  }
}