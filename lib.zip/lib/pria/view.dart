import 'package:flutter/material.dart';
import './controller.dart';
import './ContentPage.dart';

class PriaView extends StatefulWidget {
  @override
  _PriaViewState createState() => _PriaViewState();
}

class _PriaViewState extends State<PriaView> {
  List<String> names = [
    'Ahmad Yani',
    'Jendral Soedirman',
    'Idham Chalid',
    'KH. Hasyim Asyari',
    'Ki Hajar Dewantara',
    'Pangeran Antasari',
    'Pangeran Diponegoro',
    'Pattimura',
    'Ir. Soekarno',
    'Mohammad Hatta',
    'Sultan Hassanudin',
    'Agus Salim',
    'Bung Tomo',
    'Tan Malaka',
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('List Pahlawan Laki-laki'),
        backgroundColor: Colors.black,
      ),
      body: GridView.count(
        crossAxisCount: 3,
        children: List.generate(names.length, (index){
          return GridTile(
            child: GestureDetector(
              child: Container(
                width: 55.0,
                height: 60.0,
                 margin: const EdgeInsets.all(3.0),
                 padding: const EdgeInsets.all(3.0),
                decoration: BoxDecoration(
                  image: DecorationImage(
                    fit: BoxFit.fill,
                    alignment: FractionalOffset(0.2, 0.6),
                    image: AssetImage('images/'+ names[index]+'.jpg'),
                  )
                ),
              ),
          onTap: (){
            Navigator.push(context, MaterialPageRoute(
              builder: (BuildContext context){
                return ContentPage(value: names[index]); // kirim data 
              }
            ));
            },
            ),
          );
        }),
      ),
    );
  }
}
