import 'package:flutter/material.dart';
import './view.dart';

abstract class PriaController extends State<PriaView>{

}