import 'package:flutter/material.dart';
import './controller.dart';

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Fluid Sidebar',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
    );
  }
}


class HomeView extends StatefulWidget {
  @override
  _HomeViewState createState() => _HomeViewState();
}

class _HomeViewState extends HomeController {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Pahlawan'),
        backgroundColor: Colors.black, 
       ),
       drawer: Drawer(
         child: ListView(
           padding: EdgeInsets.all(0.0),
           children: <Widget>[
              UserAccountsDrawerHeader(
                accountEmail: Text('Jason@gmail.com'),
                accountName: Text('Jason'), 
              ),
             ListTile(
              onTap: () => Navigator.of(context).pushNamed('/'),
              title: Text('Home'),
              leading: CircleAvatar(
                child: Icon(Icons.apps),
              ),
             ),
             ListTile(
              onTap: () => Navigator.of(context).pushNamed('/pria'),
              title: Text('Pahlawan laki-laki'),
              leading: CircleAvatar(
                child: Icon(Icons.shop),
              ),
             ),
             ListTile(
              onTap: () => Navigator.of(context).pushNamed('/perempuan'),
              title: Text('Pahlawan wanita'),
              leading: CircleAvatar(
                child: Icon(Icons.attach_money),
              ),
             ),
             Divider(),
             ListTile(
              title: Text('Log out'),
              leading: CircleAvatar(
                child: Icon(Icons.verified_user),
              ),
             )
           ],
         ),
       ),
       body: SingleChildScrollView(
         child: Container(
           alignment: Alignment(0.0, 0.0),
           child: Text('Selamat datang, applikasi ini membahas tentang pahlawan-pahlawan indonesia',
           textDirection: TextDirection.ltr,
           style: TextStyle(fontSize: 30),
           ),
         ),
       ),
      );
  }
}