import 'package:flutter/material.dart';
import './view.dart';

abstract class HomeController extends State<HomeView>{
    
}